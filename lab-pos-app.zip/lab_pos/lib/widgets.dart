import 'package:flutter/material.dart';

import 'models.dart';
import 'theme.dart';
import 'util.dart';

Future<T?> go<T>(BuildContext context, Widget page) {
  return Navigator.of(context).push<T>(MaterialPageRoute<T>(builder: (_) => page));
}

void toast(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

InputDecoration field(String label, {String? hint}) {
  OutlineInputBorder b(Color c) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: c, width: 2),
      );
  return InputDecoration(
    labelText: label,
    hintText: hint,
    filled: true,
    fillColor: Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
    border: b(C.line),
    enabledBorder: b(C.line),
    focusedBorder: b(C.primary),
  );
}

enum BigStyle { primary, outline, amber }

class BigButton extends StatelessWidget {
  const BigButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.style = BigStyle.primary,
    this.height = 56,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final BigStyle style;
  final double height;

  @override
  Widget build(BuildContext context) {
    final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(16));
    final text = Text(
      label,
      textAlign: TextAlign.center,
      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
    );
    final Widget child = icon == null
        ? text
        : Row(
            mainAxisSize: MainAxisSize.min,
            children: [Icon(icon, size: 22), const SizedBox(width: 10), Flexible(child: text)],
          );
    switch (style) {
      case BigStyle.outline:
        return OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            minimumSize: Size.fromHeight(height),
            foregroundColor: C.ink,
            backgroundColor: Colors.white,
            side: const BorderSide(color: C.line, width: 2),
            shape: shape,
          ),
          child: child,
        );
      case BigStyle.amber:
        return ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            minimumSize: Size.fromHeight(height),
            foregroundColor: C.amberText,
            backgroundColor: C.amberBg,
            elevation: 0,
            shape: shape,
          ),
          child: child,
        );
      case BigStyle.primary:
        return ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            minimumSize: Size.fromHeight(height),
            foregroundColor: Colors.white,
            backgroundColor: C.primary,
            elevation: 0,
            shape: shape,
          ),
          child: child,
        );
    }
  }
}

class Box extends StatelessWidget {
  const Box({
    super.key,
    required this.child,
    this.color = Colors.white,
    this.border = C.line,
    this.padding = const EdgeInsets.all(16),
  });

  final Widget child;
  final Color color;
  final Color border;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        border: Border.all(color: border),
        borderRadius: BorderRadius.circular(18),
      ),
      child: child,
    );
  }
}

class Pill extends StatelessWidget {
  const Pill(this.text, {super.key, required this.bg, required this.fg});

  final String text;
  final Color bg;
  final Color fg;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
      child: Text(
        text,
        style: TextStyle(color: fg, fontSize: 14, fontWeight: FontWeight.w700),
      ),
    );
  }
}

Widget statusPill(String status) {
  switch (status) {
    case 'Report sent':
      return const Pill('Report sent', bg: C.tint, fg: C.primary);
    case 'Ready to sign':
      return const Pill('Ready to sign', bg: C.greenBg, fg: C.greenText);
    default:
      return const Pill('Sample taken', bg: C.amberBg, fg: C.amberText);
  }
}

/// Result flag shown next to a test value.
Widget flagPill(String flag) {
  switch (flag) {
    case 'LOW':
      return const Pill('LOW', bg: C.blueBg, fg: C.blueText);
    case 'HIGH':
      return const Pill('HIGH', bg: C.redBg, fg: C.redText);
    case 'OK':
      return const Pill('Normal', bg: C.greenBg, fg: C.greenText);
    default:
      return const SizedBox.shrink();
  }
}

class VisitTile extends StatelessWidget {
  const VisitTile({super.key, required this.visit, required this.onTap});

  final Visit visit;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: C.line),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              CircleAvatar(
                radius: 22,
                backgroundColor: C.tint,
                child: Text(
                  initials(visit.patient.name),
                  style: const TextStyle(color: C.primary, fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      visit.patient.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                    Text(
                      '${visit.testNames}  •  ${visit.billNo}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 14, color: C.muted),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  statusPill(visit.statusText),
                  if (visit.isDue) ...[
                    const SizedBox(height: 4),
                    Text(
                      'Due ${rupee(visit.total)}',
                      style: const TextStyle(
                          fontSize: 13, fontWeight: FontWeight.w800, color: C.amberText),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
