import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'models.dart';
import 'seed.dart';

/// Names of the files that are shared through Google Drive.
/// Anything else that appears on Drive is ignored.
final RegExp syncNameRe = RegExp(r'^(lab|catalogue|visit_[A-Za-z0-9_\-]+)\.json$');

String _randomText(int n, String chars) {
  final r = Random.secure();
  return List.generate(n, (_) => chars[r.nextInt(chars.length)]).join();
}

/// Lab letterhead details. Shared between phones.
class LabInfo {
  LabInfo({
    this.name = '',
    this.address = '',
    this.phone = '',
    this.pathologist = '',
    this.qualification = '',
    this.regNo = '',
    this.updatedAt = 0,
  });

  String name;
  String address;
  String phone;
  String pathologist;
  String qualification;
  String regNo;
  int updatedAt;

  Map<String, dynamic> toJson() => {
        'updatedAt': updatedAt,
        'name': name,
        'address': address,
        'phone': phone,
        'pathologist': pathologist,
        'qualification': qualification,
        'regNo': regNo,
      };

  factory LabInfo.fromJson(Map<String, dynamic> j) => LabInfo(
        name: (j['name'] ?? '') as String,
        address: (j['address'] ?? '') as String,
        phone: (j['phone'] ?? '') as String,
        pathologist: (j['pathologist'] ?? '') as String,
        qualification: (j['qualification'] ?? '') as String,
        regNo: (j['regNo'] ?? '') as String,
        updatedAt: (j['updatedAt'] as num?)?.toInt() ?? 0,
      );
}

/// Settings that belong to this phone only. Never uploaded.
class DeviceInfo {
  DeviceInfo({
    required this.deviceId,
    required this.prefix,
    this.billCounter = 0,
    this.driveEmail,
    this.lastSync,
  });

  String deviceId;
  String prefix; // start of bill numbers on this phone, for example KX
  int billCounter;
  String? driveEmail;
  int? lastSync;

  Map<String, dynamic> toJson() => {
        'deviceId': deviceId,
        'prefix': prefix,
        'billCounter': billCounter,
        'driveEmail': driveEmail,
        'lastSync': lastSync,
      };

  factory DeviceInfo.fromJson(Map<String, dynamic> j) => DeviceInfo(
        deviceId: j['deviceId'] as String,
        prefix: (j['prefix'] ?? 'A') as String,
        billCounter: (j['billCounter'] as num?)?.toInt() ?? 0,
        driveEmail: j['driveEmail'] as String?,
        lastSync: (j['lastSync'] as num?)?.toInt(),
      );
}

/// Keeps everything as plain JSON files in the app's private folder.
/// No database. One file per visit, so phones never overwrite each other's records.
class LabStore extends ChangeNotifier {
  LabStore._(this.dir);

  final Directory dir;
  late DeviceInfo device;
  late LabInfo lab;
  List<TestDef> catalogue = [];
  int catalogueUpdatedAt = 0;
  List<Visit> visits = [];

  /// Called after every save, so the app can start a Drive backup.
  VoidCallback? onDataChanged;

  Directory get reportsDir => Directory('${dir.path}/reports');

  static Future<LabStore> open() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/labdata');
    if (!await dir.exists()) await dir.create(recursive: true);
    final s = LabStore._(dir);
    await s.reload();
    return s;
  }

  Future<Map<String, dynamic>?> _readJson(String name) async {
    final f = File('${dir.path}/$name');
    if (!await f.exists()) return null;
    try {
      return jsonDecode(await f.readAsString()) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  Future<void> _writeText(String name, String text) async {
    final tmp = File('${dir.path}/$name.tmp');
    await tmp.writeAsString(text, flush: true);
    await tmp.rename('${dir.path}/$name');
  }

  Future<void> _saveDevice() => _writeText('device.json', jsonEncode(device.toJson()));

  Future<void> _saveCatalogueFile() => _writeText(
        'catalogue.json',
        jsonEncode({
          'updatedAt': catalogueUpdatedAt,
          'tests': catalogue.map((t) => t.toJson()).toList(),
        }),
      );

  /// Reads everything from the files again.
  Future<void> reload() async {
    final d = await _readJson('device.json');
    if (d == null) {
      device = DeviceInfo(
        deviceId: _randomText(6, 'abcdefghijklmnopqrstuvwxyz0123456789'),
        prefix: _randomText(2, 'ABCDEFGHJKLMNPQRSTUVWXYZ'),
      );
      await _saveDevice();
    } else {
      device = DeviceInfo.fromJson(d);
    }

    final l = await _readJson('lab.json');
    lab = l == null ? LabInfo() : LabInfo.fromJson(l);

    final c = await _readJson('catalogue.json');
    if (c == null) {
      catalogue = defaultCatalogue();
      catalogueUpdatedAt = 0;
      await _saveCatalogueFile();
    } else {
      catalogueUpdatedAt = (c['updatedAt'] as num?)?.toInt() ?? 0;
      catalogue = ((c['tests'] ?? []) as List)
          .map((e) => TestDef.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    }

    final list = <Visit>[];
    await for (final e in dir.list()) {
      if (e is! File) continue;
      final n = e.uri.pathSegments.last;
      if (!n.startsWith('visit_') || !n.endsWith('.json')) continue;
      try {
        list.add(Visit.fromJson(jsonDecode(await e.readAsString()) as Map<String, dynamic>));
      } catch (_) {
        // A damaged file is skipped, never deleted.
      }
    }
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    visits = list;
    notifyListeners();
  }

  // ---------- saving ----------

  Future<void> saveVisit(Visit v) async {
    v.updatedAt = DateTime.now().millisecondsSinceEpoch;
    await _writeText('visit_${v.id}.json', jsonEncode(v.toJson()));
    final i = visits.indexWhere((x) => x.id == v.id);
    if (i >= 0) {
      visits[i] = v;
    } else {
      visits.add(v);
    }
    visits.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    notifyListeners();
    onDataChanged?.call();
  }

  Future<void> saveLab(LabInfo info) async {
    info.updatedAt = DateTime.now().millisecondsSinceEpoch;
    lab = info;
    await _writeText('lab.json', jsonEncode(lab.toJson()));
    notifyListeners();
    onDataChanged?.call();
  }

  Future<void> saveCatalogue(List<TestDef> tests) async {
    catalogue = tests;
    catalogueUpdatedAt = DateTime.now().millisecondsSinceEpoch;
    await _saveCatalogueFile();
    notifyListeners();
    onDataChanged?.call();
  }

  Future<String> nextBillNumber() async {
    device.billCounter += 1;
    await _saveDevice();
    return '${device.prefix}-${device.billCounter.toString().padLeft(4, '0')}';
  }

  Future<void> setPrefix(String prefix) async {
    device.prefix = prefix;
    await _saveDevice();
    notifyListeners();
  }

  Future<void> setDriveEmail(String? email) async {
    device.driveEmail = email;
    await _saveDevice();
    notifyListeners();
  }

  Future<void> markSynced() async {
    device.lastSync = DateTime.now().millisecondsSinceEpoch;
    await _saveDevice();
    notifyListeners();
  }

  // ---------- helpers for Drive sync ----------

  Future<List<String>> syncFileNames() async {
    final names = <String>[];
    await for (final e in dir.list()) {
      if (e is! File) continue;
      final n = e.uri.pathSegments.last;
      if (syncNameRe.hasMatch(n)) names.add(n);
    }
    return names;
  }

  Future<int> updatedAtOf(String name) async {
    final j = await _readJson(name);
    return (j?['updatedAt'] as num?)?.toInt() ?? 0;
  }

  Future<List<int>> readBytes(String name) => File('${dir.path}/$name').readAsBytes();

  Future<int> totalSyncBytes() async {
    var total = 0;
    for (final n in await syncFileNames()) {
      total += await File('${dir.path}/$n').length();
    }
    return total;
  }

  /// Saves a file that came from Drive. Only known file names are accepted,
  /// and the content must be valid JSON.
  Future<bool> writeFromDrive(String name, List<int> bytes) async {
    if (!syncNameRe.hasMatch(name)) return false;
    try {
      jsonDecode(utf8.decode(bytes));
    } catch (_) {
      return false;
    }
    await _writeText(name, utf8.decode(bytes));
    return true;
  }
}
