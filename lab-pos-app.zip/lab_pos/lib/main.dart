import 'dart:async';

import 'package:flutter/material.dart';

import 'drive_sync.dart';
import 'globals.dart';
import 'screens/home_screen.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  store = await LabStore.open();
  cloud = DriveSync(store);
  store.onDataChanged = cloud.scheduleSync;
  runApp(const LabPosApp());
  unawaited(cloud.init());
}

class LabPosApp extends StatelessWidget {
  const LabPosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lab POS',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const HomeScreen(),
    );
  }
}
