import 'dart:io';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'models.dart';
import 'store.dart';
import 'util.dart';

/// The built-in PDF font covers basic Latin only, so a few symbols are swapped.
String _safe(String s) => s
    .replaceAll('–', '-')
    .replaceAll('—', '-')
    .replaceAll('₹', 'Rs.')
    .replaceAll('·', '|');

pw.Widget _cell(String text, {bool bold = false}) => pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      child: pw.Text(
        _safe(text),
        style: pw.TextStyle(
          fontSize: 10,
          fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
        ),
      ),
    );

pw.Widget _info(String label, String value) => pw.Row(
      children: [
        pw.Text('$label: ', style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
        pw.Expanded(
          child: pw.Text(_safe(value),
              style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
        ),
      ],
    );

/// Builds the report PDF and saves it as reports/<bill number>.pdf
Future<File> buildReportPdf(Visit v, LabInfo lab, Directory reportsDir) async {
  final g = v.patient.gender;
  final doc = pw.Document();

  final rows = <pw.TableRow>[
    pw.TableRow(
      decoration: const pw.BoxDecoration(color: PdfColors.grey200),
      children: [
        _cell('Test', bold: true),
        _cell('Result', bold: true),
        _cell('Unit', bold: true),
        _cell('Reference', bold: true),
      ],
    ),
  ];
  for (final t in v.tests) {
    rows.add(pw.TableRow(children: [_cell(t.name, bold: true), _cell(''), _cell(''), _cell('')]));
    for (final p in t.params) {
      final val = t.values[p.name] ?? '';
      final f = p.flag(val, g);
      final mark = f == 'LOW' ? ' L' : (f == 'HIGH' ? ' H' : '');
      rows.add(pw.TableRow(children: [
        _cell('   ${p.name}'),
        _cell('$val$mark', bold: mark.isNotEmpty),
        _cell(p.unit),
        _cell(p.rangeText(g)),
      ]));
    }
  }

  final labName = lab.name.isEmpty ? '[Lab name]' : lab.name;
  final contact = [lab.address, lab.phone].where((s) => s.isNotEmpty).join('  |  ');

  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (ctx) => [
        pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 8),
          decoration: const pw.BoxDecoration(
            border: pw.Border(bottom: pw.BorderSide(width: 2, color: PdfColors.indigo800)),
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(_safe(labName),
                  style: pw.TextStyle(
                      fontSize: 20, fontWeight: pw.FontWeight.bold, color: PdfColors.indigo800)),
              if (contact.isNotEmpty)
                pw.Text(_safe(contact),
                    style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
            ],
          ),
        ),
        pw.SizedBox(height: 12),
        pw.Row(children: [
          pw.Expanded(child: _info('Patient', v.patient.name)),
          pw.Expanded(child: _info('Age/Sex', v.patient.ageSex)),
        ]),
        pw.SizedBox(height: 4),
        pw.Row(children: [
          pw.Expanded(child: _info('Sample ID', v.billNo)),
          pw.Expanded(child: _info('Date', fmtDate(v.createdAt))),
        ]),
        pw.SizedBox(height: 4),
        _info('Referred by', v.patient.referredBy),
        pw.SizedBox(height: 14),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.5),
          columnWidths: {
            0: const pw.FlexColumnWidth(3),
            1: const pw.FlexColumnWidth(1.5),
            2: const pw.FlexColumnWidth(1.5),
            3: const pw.FlexColumnWidth(2),
          },
          children: rows,
        ),
        pw.SizedBox(height: 6),
        pw.Text('L = below reference range, H = above reference range',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
        pw.SizedBox(height: 36),
        pw.Container(
          padding: const pw.EdgeInsets.only(top: 8),
          decoration: const pw.BoxDecoration(
            border: pw.Border(top: pw.BorderSide(width: 0.5, color: PdfColors.grey600)),
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(_safe(lab.pathologist.isEmpty ? '[Pathologist name]' : lab.pathologist),
                  style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
              pw.Text(
                _safe([
                  lab.qualification.isEmpty ? '[Qualification]' : lab.qualification,
                  'Reg. no. ${lab.regNo.isEmpty ? '[Registration no.]' : lab.regNo}',
                ].join('  |  ')),
                style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  await reportsDir.create(recursive: true);
  final file = File('${reportsDir.path}/${v.billNo}.pdf');
  await file.writeAsBytes(await doc.save());
  return file;
}
