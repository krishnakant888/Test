String _num(double v) {
  if (v == v.roundToDouble()) return v.toInt().toString();
  return v.toString();
}

/// One measured value inside a test (for example Hemoglobin inside CBC).
class Param {
  Param({
    required this.name,
    this.unit = '',
    this.low,
    this.high,
    this.lowM,
    this.highM,
  });

  String name;
  String unit;
  double? low;
  double? high;
  // Optional separate range for male patients.
  double? lowM;
  double? highM;

  Map<String, dynamic> toJson() => {
        'name': name,
        'unit': unit,
        'low': low,
        'high': high,
        'lowM': lowM,
        'highM': highM,
      };

  factory Param.fromJson(Map<String, dynamic> j) => Param(
        name: j['name'] as String,
        unit: (j['unit'] ?? '') as String,
        low: (j['low'] as num?)?.toDouble(),
        high: (j['high'] as num?)?.toDouble(),
        lowM: (j['lowM'] as num?)?.toDouble(),
        highM: (j['highM'] as num?)?.toDouble(),
      );

  Param copy() => Param.fromJson(toJson());

  bool _useMale(String gender) => gender == 'M' && (lowM != null || highM != null);

  double? lowFor(String gender) => _useMale(gender) ? lowM : low;
  double? highFor(String gender) => _useMale(gender) ? highM : high;

  String rangeText(String gender) {
    final l = lowFor(gender);
    final h = highFor(gender);
    if (l != null && h != null) return '${_num(l)}-${_num(h)}';
    if (h != null) return 'up to ${_num(h)}';
    if (l != null) return 'above ${_num(l)}';
    return '';
  }

  /// Returns LOW, HIGH, OK, or an empty string when the value is empty or has no range.
  String flag(String value, String gender) {
    final v = double.tryParse(value.replaceAll(',', '').trim());
    if (v == null) return '';
    final l = lowFor(gender);
    final h = highFor(gender);
    if (l == null && h == null) return '';
    if (l != null && v < l) return 'LOW';
    if (h != null && v > h) return 'HIGH';
    return 'OK';
  }
}

/// A test in the lab's price list.
class TestDef {
  TestDef({
    required this.id,
    required this.name,
    required this.price,
    required this.params,
  });

  String id;
  String name;
  int price;
  List<Param> params;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'price': price,
        'params': params.map((p) => p.toJson()).toList(),
      };

  factory TestDef.fromJson(Map<String, dynamic> j) => TestDef(
        id: j['id'] as String,
        name: j['name'] as String,
        price: (j['price'] as num).toInt(),
        params: ((j['params'] ?? []) as List)
            .map((e) => Param.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}

class Patient {
  Patient({
    required this.name,
    required this.age,
    required this.gender,
    this.mobile = '',
    this.referredBy = 'Self',
    this.homeCollection = false,
    this.consent = false,
  });

  String name;
  int age;
  String gender; // F, M or O
  String mobile;
  String referredBy;
  bool homeCollection;
  bool consent;

  String get ageSex => '$age / $gender';

  Map<String, dynamic> toJson() => {
        'name': name,
        'age': age,
        'gender': gender,
        'mobile': mobile,
        'referredBy': referredBy,
        'homeCollection': homeCollection,
        'consent': consent,
      };

  factory Patient.fromJson(Map<String, dynamic> j) => Patient(
        name: j['name'] as String,
        age: (j['age'] as num).toInt(),
        gender: (j['gender'] ?? 'O') as String,
        mobile: (j['mobile'] ?? '') as String,
        referredBy: (j['referredBy'] ?? 'Self') as String,
        homeCollection: (j['homeCollection'] ?? false) as bool,
        consent: (j['consent'] ?? false) as bool,
      );
}

/// A test on one bill. It keeps its own copy of the price and ranges,
/// so changing the price list later never changes an old bill or report.
class VisitTest {
  VisitTest({
    required this.testId,
    required this.name,
    required this.price,
    required this.params,
    Map<String, String>? values,
  }) : values = values ?? <String, String>{};

  String testId;
  String name;
  int price;
  List<Param> params;
  Map<String, String> values;

  factory VisitTest.fromDef(TestDef d) => VisitTest(
        testId: d.id,
        name: d.name,
        price: d.price,
        params: d.params.map((p) => p.copy()).toList(),
      );

  Map<String, dynamic> toJson() => {
        'testId': testId,
        'name': name,
        'price': price,
        'params': params.map((p) => p.toJson()).toList(),
        'values': values,
      };

  factory VisitTest.fromJson(Map<String, dynamic> j) => VisitTest(
        testId: j['testId'] as String,
        name: j['name'] as String,
        price: (j['price'] as num).toInt(),
        params: ((j['params'] ?? []) as List)
            .map((e) => Param.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        values: Map<String, String>.from((j['values'] ?? {}) as Map),
      );
}

/// One patient visit: patient details, bill, results and report status.
/// Each visit is saved as its own file, so two phones never overwrite each other.
class Visit {
  Visit({
    required this.id,
    required this.billNo,
    required this.createdAt,
    required this.updatedAt,
    required this.deviceId,
    required this.patient,
    required this.tests,
    this.discountPercent = 0,
    this.payMode = 'cash',
    this.duePaidAt,
    this.signedAt,
  });

  String id;
  String billNo;
  int createdAt;
  int updatedAt;
  String deviceId;
  Patient patient;
  List<VisitTest> tests;
  int discountPercent;
  String payMode; // cash, upi or due
  int? duePaidAt;
  int? signedAt;

  int get subtotal => tests.fold<int>(0, (s, t) => s + t.price);
  int get discount => (subtotal * discountPercent / 100).round();
  int get total => subtotal - discount;
  bool get isDue => payMode == 'due' && duePaidAt == null;

  bool get resultsComplete => tests.every(
      (t) => t.params.every((p) => (t.values[p.name] ?? '').trim().isNotEmpty));

  String get statusText {
    if (signedAt != null) return 'Report sent';
    if (resultsComplete) return 'Ready to sign';
    return 'Sample taken';
  }

  String get testNames => tests.map((t) => t.name).join(', ');

  Map<String, dynamic> toJson() => {
        'id': id,
        'billNo': billNo,
        'createdAt': createdAt,
        'updatedAt': updatedAt,
        'deviceId': deviceId,
        'patient': patient.toJson(),
        'tests': tests.map((t) => t.toJson()).toList(),
        'discountPercent': discountPercent,
        'payMode': payMode,
        'duePaidAt': duePaidAt,
        'signedAt': signedAt,
      };

  factory Visit.fromJson(Map<String, dynamic> j) => Visit(
        id: j['id'] as String,
        billNo: j['billNo'] as String,
        createdAt: (j['createdAt'] as num).toInt(),
        updatedAt: (j['updatedAt'] as num?)?.toInt() ?? 0,
        deviceId: (j['deviceId'] ?? '') as String,
        patient: Patient.fromJson(Map<String, dynamic>.from(j['patient'] as Map)),
        tests: ((j['tests'] ?? []) as List)
            .map((e) => VisitTest.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        discountPercent: (j['discountPercent'] as num?)?.toInt() ?? 0,
        payMode: (j['payMode'] ?? 'cash') as String,
        duePaidAt: (j['duePaidAt'] as num?)?.toInt(),
        signedAt: (j['signedAt'] as num?)?.toInt(),
      );
}
