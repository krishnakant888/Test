import 'models.dart';

/// Starter price list. Prices and reference ranges are SAMPLES.
/// The lab and its pathologist must check and edit them (Settings > Tests and prices).
List<TestDef> defaultCatalogue() => [
      TestDef(id: 'cbc', name: 'CBC', price: 350, params: [
        Param(name: 'Hemoglobin', unit: 'g/dL', low: 12.0, high: 15.5, lowM: 13.5, highM: 17.5),
        Param(name: 'WBC count', unit: '/µL', low: 4000, high: 11000),
        Param(name: 'Platelets', unit: '×10³/µL', low: 150, high: 450),
      ]),
      TestDef(id: 'lipid', name: 'Lipid profile', price: 600, params: [
        Param(name: 'Total cholesterol', unit: 'mg/dL', high: 200),
        Param(name: 'Triglycerides', unit: 'mg/dL', high: 150),
        Param(name: 'HDL cholesterol', unit: 'mg/dL', low: 40),
        Param(name: 'LDL cholesterol', unit: 'mg/dL', high: 100),
      ]),
      TestDef(id: 'hba1c', name: 'HbA1c', price: 450, params: [
        Param(name: 'HbA1c', unit: '%', low: 4.0, high: 5.6),
      ]),
      TestDef(id: 'tsh', name: 'TSH', price: 300, params: [
        Param(name: 'TSH', unit: 'µIU/mL', low: 0.4, high: 4.0),
      ]),
      TestDef(id: 'fbs', name: 'Blood sugar (fasting)', price: 80, params: [
        Param(name: 'Glucose fasting', unit: 'mg/dL', low: 70, high: 99),
      ]),
      TestDef(id: 'creat', name: 'Serum creatinine', price: 200, params: [
        Param(name: 'Creatinine', unit: 'mg/dL', low: 0.6, high: 1.3),
      ]),
    ];
