import 'package:flutter/material.dart';

class C {
  static const bg = Color(0xFFF5F7FA);
  static const ink = Color(0xFF101B2D);
  static const muted = Color(0xFF566174);
  static const line = Color(0xFFDDE3EC);
  static const primary = Color(0xFF2F3FB8);
  static const tint = Color(0xFFE8EAFB);
  static const amberBg = Color(0xFFFEF3C7);
  static const amberLine = Color(0xFFF5D98B);
  static const amberText = Color(0xFF92400E);
  static const greenBg = Color(0xFFDCFCE7);
  static const greenText = Color(0xFF166534);
  static const blueBg = Color(0xFFE0E7FF);
  static const blueText = Color(0xFF1E3A8A);
  static const redBg = Color(0xFFFEE2E2);
  static const redText = Color(0xFF991B1B);
}

ThemeData buildTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorSchemeSeed: C.primary,
    scaffoldBackgroundColor: C.bg,
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(bodyColor: C.ink, displayColor: C.ink),
    appBarTheme: const AppBarTheme(
      backgroundColor: C.bg,
      foregroundColor: C.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(color: C.ink, fontSize: 22, fontWeight: FontWeight.w800),
    ),
  );
}
