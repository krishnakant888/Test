import 'package:flutter/material.dart';

import '../globals.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';

class StorageScreen extends StatelessWidget {
  const StorageScreen({super.key});

  Future<void> _switch(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Switch Google Drive account?'),
        content: const Text(
          'The app will make one last backup to the current account, then ask you to pick the new account and copy everything there. '
          'The old account is not changed or deleted. Your data stays on this phone the whole time.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Continue')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    String message;
    try {
      message = await cloud.switchAccount();
    } catch (e) {
      message = e is StateError ? e.message : e.toString();
    }
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(message),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  void _showForOtherPhones(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add another phone'),
        content: Text(
          'On the other phone, install this app, open Settings > Storage and backup, tap Connect Google Drive and sign in with:\n\n${cloud.email}\n\n'
          'Then in Lab details, give that phone a different bill prefix.',
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Storage and backup')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Listenable.merge([store, cloud]),
          builder: (context, _) {
            final q = cloud.quota;
            final frac = q?.fraction;
            final last = store.device.lastSync;
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
              children: [
                Box(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(cloud.connected ? 'Backing up to' : 'Google Drive is not connected',
                          style: const TextStyle(fontSize: 14, color: C.muted)),
                      if (cloud.connected)
                        Text(cloud.email,
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      if (!cloud.connected && cloud.email.isNotEmpty)
                        Text('Last account: ${cloud.email}',
                            style: const TextStyle(fontSize: 14, color: C.muted)),
                      const SizedBox(height: 10),
                      Text(
                        last == null
                            ? 'No backup yet'
                            : 'Last backup: ${fmtDate(last)}, ${fmtTime(last)}',
                        style: const TextStyle(fontSize: 14, color: C.muted),
                      ),
                      if (cloud.status.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          cloud.status,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: cloud.lastFailed ? C.redText : C.greenText,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                if (cloud.connected && q != null) ...[
                  const SizedBox(height: 12),
                  Box(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          q.limit == null
                              ? '${fmtBytes(q.used)} used (no limit on this account)'
                              : '${fmtBytes(q.used)} of ${fmtBytes(q.limit!)} used',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                        if (frac != null) ...[
                          const SizedBox(height: 10),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: LinearProgressIndicator(
                              value: frac.clamp(0.0, 1.0),
                              minHeight: 12,
                              color: cloud.driveFull ? C.amberText : C.primary,
                              backgroundColor: C.line,
                            ),
                          ),
                        ],
                        if (cloud.driveFull) ...[
                          const SizedBox(height: 10),
                          const Text(
                            'This Drive is almost full. Switch to another account before backups stop.',
                            style: TextStyle(color: C.amberText, fontWeight: FontWeight.w700),
                          ),
                        ],
                        const SizedBox(height: 6),
                        const Text('This is the whole Google account, not only this app.',
                            style: TextStyle(fontSize: 12, color: C.muted)),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                if (!cloud.connected)
                  BigButton(
                    label: 'Connect Google Drive',
                    icon: Icons.cloud_upload_outlined,
                    height: 60,
                    onPressed: cloud.busy ? null : () => cloud.connect(),
                  )
                else ...[
                  BigButton(
                    label: cloud.busy ? 'Working...' : 'Back up now',
                    icon: Icons.sync,
                    height: 60,
                    onPressed: cloud.busy ? null : () => cloud.syncNow(),
                  ),
                  const SizedBox(height: 10),
                  BigButton(
                    label: 'Switch Drive account',
                    style: cloud.driveFull ? BigStyle.amber : BigStyle.outline,
                    onPressed: cloud.busy ? null : () => _switch(context),
                  ),
                  const SizedBox(height: 10),
                  BigButton(
                    label: 'Add another phone',
                    style: BigStyle.outline,
                    onPressed: () => _showForOtherPhones(context),
                  ),
                ],
                const SizedBox(height: 22),
                Box(
                  color: C.tint,
                  border: C.tint,
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('How it works', style: TextStyle(fontWeight: FontWeight.w800)),
                      SizedBox(height: 6),
                      Text(
                        '1. Every bill and result is saved on this phone first, so the app works without internet.\n'
                        '2. A few seconds later the files are copied to the "LabPOS Data" folder in your Google Drive.\n'
                        '3. Other phones using the same Google account copy them in too.\n'
                        '4. If the same patient is edited on two phones, the later change wins.\n'
                        '5. Deleting is not synced. Nothing is removed from Drive by this app.',
                        style: TextStyle(fontSize: 14, height: 1.4),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
