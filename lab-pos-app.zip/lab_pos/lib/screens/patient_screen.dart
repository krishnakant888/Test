import 'package:flutter/material.dart';

import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'bill_screen.dart';

class PatientScreen extends StatefulWidget {
  const PatientScreen({super.key});

  @override
  State<PatientScreen> createState() => _PatientScreenState();
}

class _PatientScreenState extends State<PatientScreen> {
  final name = TextEditingController();
  final age = TextEditingController();
  final mobile = TextEditingController();
  final referred = TextEditingController(text: 'Self');
  String gender = 'F';
  bool home = false;
  bool consent = false;
  String? error;

  @override
  void dispose() {
    name.dispose();
    age.dispose();
    mobile.dispose();
    referred.dispose();
    super.dispose();
  }

  void _next() {
    final n = name.text.trim();
    final a = int.tryParse(age.text.trim());
    if (n.isEmpty) {
      setState(() => error = 'Enter the patient name');
      return;
    }
    if (a == null || a < 0 || a > 120) {
      setState(() => error = 'Enter a valid age');
      return;
    }
    if (!consent) {
      setState(() => error = 'Tick the box to confirm the patient agrees');
      return;
    }
    final ref = referred.text.trim();
    final p = Patient(
      name: n,
      age: a,
      gender: gender,
      mobile: mobile.text.trim(),
      referredBy: ref.isEmpty ? 'Self' : ref,
      homeCollection: home,
      consent: consent,
    );
    setState(() => error = null);
    go(context, BillScreen(patient: p));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New patient')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            TextField(
              controller: name,
              textCapitalization: TextCapitalization.words,
              decoration: field('Full name'),
            ),
            const SizedBox(height: 14),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: TextField(
                    controller: age,
                    keyboardType: TextInputType.number,
                    decoration: field('Age'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'F', label: Text('F')),
                      ButtonSegment(value: 'M', label: Text('M')),
                      ButtonSegment(value: 'O', label: Text('Other')),
                    ],
                    selected: {gender},
                    showSelectedIcon: false,
                    onSelectionChanged: (s) => setState(() => gender = s.first),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            TextField(
              controller: mobile,
              keyboardType: TextInputType.phone,
              decoration: field('Mobile number (report goes here)'),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: referred,
              textCapitalization: TextCapitalization.words,
              decoration: field('Referred by'),
            ),
            const SizedBox(height: 10),
            SwitchListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 4),
              title: const Text('Home sample collection',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              value: home,
              onChanged: (v) => setState(() => home = v),
            ),
            CheckboxListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 4),
              controlAffinity: ListTileControlAffinity.leading,
              title: const Text(
                'Patient agrees to store their details and receive the report on this number.',
                style: TextStyle(fontSize: 15, color: C.muted),
              ),
              value: consent,
              onChanged: (v) => setState(() => consent = v ?? false),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(error!, style: const TextStyle(color: C.redText, fontWeight: FontWeight.w700)),
              ),
            const SizedBox(height: 16),
            BigButton(label: 'Add tests', height: 60, onPressed: _next),
          ],
        ),
      ),
    );
  }
}
