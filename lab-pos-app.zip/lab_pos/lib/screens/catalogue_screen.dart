import 'package:flutter/material.dart';

import '../globals.dart';
import '../models.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';

class CatalogueScreen extends StatelessWidget {
  const CatalogueScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tests and prices')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => go(context, const TestEditScreen()),
        icon: const Icon(Icons.add),
        label: const Text('Add test'),
      ),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: store,
          builder: (context, _) {
            final tests = store.catalogue;
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 96),
              children: [
                const Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: Text(
                    'Normal ranges here are only examples. Check every range with your pathologist before using it for real patients.',
                    style: TextStyle(fontSize: 13, color: C.amberText, fontWeight: FontWeight.w600),
                  ),
                ),
                if (tests.isEmpty)
                  const Box(child: Text('No tests yet. Tap "Add test".')),
                for (final t in tests)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Material(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: const BorderSide(color: C.line),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => go(context, TestEditScreen(testId: t.id)),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(t.name,
                                        style: const TextStyle(
                                            fontSize: 16, fontWeight: FontWeight.w800)),
                                    Text('${t.params.length} result fields',
                                        style: const TextStyle(fontSize: 14, color: C.muted)),
                                  ],
                                ),
                              ),
                              Text(rupee(t.price),
                                  style: const TextStyle(
                                      fontSize: 16, fontWeight: FontWeight.w800)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _ParamCtl {
  _ParamCtl(Param p)
      : name = TextEditingController(text: p.name),
        unit = TextEditingController(text: p.unit),
        low = TextEditingController(text: _s(p.low)),
        high = TextEditingController(text: _s(p.high)),
        lowM = TextEditingController(text: _s(p.lowM)),
        highM = TextEditingController(text: _s(p.highM));

  final TextEditingController name;
  final TextEditingController unit;
  final TextEditingController low;
  final TextEditingController high;
  final TextEditingController lowM;
  final TextEditingController highM;

  static String _s(double? v) {
    if (v == null) return '';
    return v == v.roundToDouble() ? v.toInt().toString() : v.toString();
  }

  static double? _d(TextEditingController c) => double.tryParse(c.text.trim());

  Param toParam() => Param(
        name: name.text.trim(),
        unit: unit.text.trim(),
        low: _d(low),
        high: _d(high),
        lowM: _d(lowM),
        highM: _d(highM),
      );

  void dispose() {
    for (final c in [name, unit, low, high, lowM, highM]) {
      c.dispose();
    }
  }
}

class TestEditScreen extends StatefulWidget {
  const TestEditScreen({super.key, this.testId});

  final String? testId;

  @override
  State<TestEditScreen> createState() => _TestEditScreenState();
}

class _TestEditScreenState extends State<TestEditScreen> {
  final name = TextEditingController();
  final price = TextEditingController();
  final List<_ParamCtl> params = [];
  String? error;

  bool get isNew => widget.testId == null;

  @override
  void initState() {
    super.initState();
    if (!isNew) {
      final found = store.catalogue.where((t) => t.id == widget.testId).toList();
      if (found.isNotEmpty) {
        final t = found.first;
        name.text = t.name;
        price.text = t.price.toString();
        for (final p in t.params) {
          params.add(_ParamCtl(p));
        }
      }
    }
  }

  @override
  void dispose() {
    name.dispose();
    price.dispose();
    for (final p in params) {
      p.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    final n = name.text.trim();
    final pr = int.tryParse(price.text.trim());
    if (n.isEmpty) {
      setState(() => error = 'Enter the test name');
      return;
    }
    if (pr == null || pr < 0) {
      setState(() => error = 'Enter the price in rupees');
      return;
    }
    final ps = params.map((c) => c.toParam()).where((p) => p.name.isNotEmpty).toList();
    final seen = <String>{};
    for (final p in ps) {
      if (!seen.add(p.name)) {
        setState(() => error = 'Two result fields are named "${p.name}". Use different names.');
        return;
      }
    }
    final nav = Navigator.of(context);
    final list = List<TestDef>.from(store.catalogue);
    if (isNew) {
      list.add(TestDef(
        id: 't_${store.device.deviceId}_${DateTime.now().millisecondsSinceEpoch}',
        name: n,
        price: pr,
        params: ps,
      ));
    } else {
      final i = list.indexWhere((t) => t.id == widget.testId);
      if (i >= 0) {
        list[i] = TestDef(id: list[i].id, name: n, price: pr, params: ps);
      }
    }
    await store.saveCatalogue(list);
    nav.pop();
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete this test?'),
        content: const Text(
            'Old bills and reports keep their own copy, so they will not change. Only new bills are affected.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final nav = Navigator.of(context);
    final list = store.catalogue.where((t) => t.id != widget.testId).toList();
    await store.saveCatalogue(list);
    nav.pop();
  }

  Widget _num(TextEditingController c, String label) => Expanded(
        child: TextField(
          controller: c,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: field(label),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isNew ? 'Add test' : 'Edit test'),
        actions: [
          if (!isNew)
            IconButton(
              tooltip: 'Delete test',
              onPressed: _delete,
              icon: const Icon(Icons.delete_outline),
            ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            TextField(
                controller: name,
                textCapitalization: TextCapitalization.words,
                decoration: field('Test name')),
            const SizedBox(height: 14),
            TextField(
              controller: price,
              keyboardType: TextInputType.number,
              decoration: field('Price (₹)'),
            ),
            const SizedBox(height: 22),
            const Text('Result fields',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            const Text(
              'One row for each value you type in a report. Leave the male range empty if men and women have the same range.',
              style: TextStyle(fontSize: 13, color: C.muted),
            ),
            const SizedBox(height: 10),
            for (var i = 0; i < params.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Box(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: TextField(
                                controller: params[i].name, decoration: field('Name')),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            flex: 2,
                            child: TextField(
                                controller: params[i].unit, decoration: field('Unit')),
                          ),
                          IconButton(
                            tooltip: 'Remove field',
                            onPressed: () => setState(() {
                              params[i].dispose();
                              params.removeAt(i);
                            }),
                            icon: const Icon(Icons.close),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(children: [
                        _num(params[i].low, 'Low'),
                        const SizedBox(width: 8),
                        _num(params[i].high, 'High'),
                      ]),
                      const SizedBox(height: 8),
                      Row(children: [
                        _num(params[i].lowM, 'Male low'),
                        const SizedBox(width: 8),
                        _num(params[i].highM, 'Male high'),
                      ]),
                    ],
                  ),
                ),
              ),
            BigButton(
              label: 'Add result field',
              icon: Icons.add,
              style: BigStyle.outline,
              onPressed: () => setState(() => params.add(_ParamCtl(Param(name: '')))),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(error!,
                    style: const TextStyle(color: C.redText, fontWeight: FontWeight.w700)),
              ),
            const SizedBox(height: 20),
            BigButton(label: 'Save', height: 60, onPressed: _save),
          ],
        ),
      ),
    );
  }
}
