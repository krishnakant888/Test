import 'package:flutter/material.dart';

import '../globals.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class LabScreen extends StatefulWidget {
  const LabScreen({super.key});

  @override
  State<LabScreen> createState() => _LabScreenState();
}

class _LabScreenState extends State<LabScreen> {
  late final TextEditingController name;
  late final TextEditingController address;
  late final TextEditingController phone;
  late final TextEditingController pathologist;
  late final TextEditingController qualification;
  late final TextEditingController regNo;
  late final TextEditingController prefix;
  String? error;

  @override
  void initState() {
    super.initState();
    final l = store.lab;
    name = TextEditingController(text: l.name);
    address = TextEditingController(text: l.address);
    phone = TextEditingController(text: l.phone);
    pathologist = TextEditingController(text: l.pathologist);
    qualification = TextEditingController(text: l.qualification);
    regNo = TextEditingController(text: l.regNo);
    prefix = TextEditingController(text: store.device.prefix);
  }

  @override
  void dispose() {
    for (final c in [name, address, phone, pathologist, qualification, regNo, prefix]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    final pre = prefix.text.trim().toUpperCase();
    if (!RegExp(r'^[A-Z0-9]{1,4}$').hasMatch(pre)) {
      setState(() => error = 'Bill prefix must be 1 to 4 letters or numbers');
      return;
    }
    final nav = Navigator.of(context);
    await store.setPrefix(pre);
    await store.saveLab(LabInfo(
      name: name.text.trim(),
      address: address.text.trim(),
      phone: phone.text.trim(),
      pathologist: pathologist.text.trim(),
      qualification: qualification.text.trim(),
      regNo: regNo.text.trim(),
    ));
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    Widget gap() => const SizedBox(height: 14);
    return Scaffold(
      appBar: AppBar(title: const Text('Lab details')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            TextField(
                controller: name,
                textCapitalization: TextCapitalization.words,
                decoration: field('Lab name')),
            gap(),
            TextField(
                controller: address,
                maxLines: 2,
                textCapitalization: TextCapitalization.words,
                decoration: field('Address')),
            gap(),
            TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: field('Lab phone')),
            gap(),
            TextField(
                controller: pathologist,
                textCapitalization: TextCapitalization.words,
                decoration: field('Pathologist name')),
            gap(),
            TextField(
                controller: qualification,
                decoration: field('Qualification', hint: 'For example MD Pathology')),
            gap(),
            TextField(controller: regNo, decoration: field('Registration number')),
            const SizedBox(height: 8),
            const Text(
              'The pathologist name, qualification and registration number are printed on every report. Enter them exactly as on the registration certificate.',
              style: TextStyle(fontSize: 13, color: C.muted),
            ),
            const SizedBox(height: 22),
            const Text('This phone', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            TextField(
              controller: prefix,
              textCapitalization: TextCapitalization.characters,
              decoration: field('Bill number prefix'),
            ),
            const SizedBox(height: 6),
            const Text(
              'Use a different prefix on each phone (for example A on one, B on the other). Then two phones never make the same bill number.',
              style: TextStyle(fontSize: 13, color: C.muted),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(error!,
                    style: const TextStyle(color: C.redText, fontWeight: FontWeight.w700)),
              ),
            const SizedBox(height: 20),
            BigButton(label: 'Save', height: 60, onPressed: _save),
          ],
        ),
      ),
    );
  }
}
