import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets.dart';
import 'catalogue_screen.dart';
import 'lab_screen.dart';
import 'storage_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData icon, String title, String sub, Widget page) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Material(
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: C.line),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => go(context, page),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(icon, color: C.primary, size: 28),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                        Text(sub, style: const TextStyle(fontSize: 14, color: C.muted)),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: C.muted),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            tile(Icons.local_hospital_outlined, 'Lab details',
                'Name, address and pathologist on the report', const LabScreen()),
            tile(Icons.science_outlined, 'Tests and prices',
                'Add or change tests, prices and normal ranges', const CatalogueScreen()),
            tile(Icons.cloud_outlined, 'Storage and backup',
                'Google Drive account and backup status', const StorageScreen()),
          ],
        ),
      ),
    );
  }
}
