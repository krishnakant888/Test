import 'package:flutter/material.dart';

import '../globals.dart';
import '../models.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';

class BillScreen extends StatefulWidget {
  const BillScreen({super.key, required this.patient});

  final Patient patient;

  @override
  State<BillScreen> createState() => _BillScreenState();
}

class _BillScreenState extends State<BillScreen> {
  final Set<String> selected = {};
  String query = '';
  int discount = 0;
  bool saving = false;

  List<TestDef> get chosen => store.catalogue.where((t) => selected.contains(t.id)).toList();
  int get subtotal => chosen.fold<int>(0, (s, t) => s + t.price);
  int get discountAmount => (subtotal * discount / 100).round();
  int get total => subtotal - discountAmount;

  Future<void> _save(String mode) async {
    if (selected.isEmpty) {
      toast(context, 'Pick at least one test');
      return;
    }
    if (saving) return;
    setState(() => saving = true);
    final messenger = ScaffoldMessenger.of(context);
    final nav = Navigator.of(context);
    final now = DateTime.now().millisecondsSinceEpoch;
    final billNo = await store.nextBillNumber();
    final visit = Visit(
      id: '${store.device.deviceId}_$now',
      billNo: billNo,
      createdAt: now,
      updatedAt: now,
      deviceId: store.device.deviceId,
      patient: widget.patient,
      tests: chosen.map((d) => VisitTest.fromDef(d)).toList(),
      discountPercent: discount,
      payMode: mode,
    );
    await store.saveVisit(visit);
    nav.popUntil((r) => r.isFirst);
    messenger.showSnackBar(SnackBar(content: Text('Bill ${visit.billNo} saved. Sample ID: ${visit.billNo}')));
  }

  @override
  Widget build(BuildContext context) {
    final shown = store.catalogue
        .where((t) => t.name.toLowerCase().contains(query.trim().toLowerCase()))
        .toList();
    final picked = chosen;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('New bill', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            Text(
              '${widget.patient.name} · ${widget.patient.ageSex}',
              style: const TextStyle(fontSize: 14, color: C.muted, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                children: [
                  TextField(
                    decoration: field('Search test').copyWith(prefixIcon: const Icon(Icons.search)),
                    onChanged: (t) => setState(() => query = t),
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final t in shown)
                        FilterChip(
                          label: Text('${t.name}  ${rupee(t.price)}'),
                          selected: selected.contains(t.id),
                          showCheckmark: true,
                          onSelected: (on) {
                            setState(() {
                              if (on) {
                                selected.add(t.id);
                              } else {
                                selected.remove(t.id);
                              }
                            });
                          },
                        ),
                    ],
                  ),
                  if (shown.isEmpty)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text('No test with this name. Add it in Settings > Tests and prices.',
                          style: TextStyle(color: C.muted)),
                    ),
                  const SizedBox(height: 20),
                  Text('Tests added (${picked.length})',
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Box(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: picked.isEmpty
                        ? const Padding(
                            padding: EdgeInsets.symmetric(vertical: 14),
                            child: Text('Tap a test above to add it',
                                style: TextStyle(color: C.muted)),
                          )
                        : Column(
                            children: [
                              for (final t in picked)
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(t.name,
                                            style: const TextStyle(
                                                fontSize: 16, fontWeight: FontWeight.w700)),
                                      ),
                                      Text(rupee(t.price),
                                          style: const TextStyle(
                                              fontSize: 16, fontWeight: FontWeight.w700)),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                  ),
                  const SizedBox(height: 14),
                  const Text('Discount', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    children: [
                      for (final d in const [0, 5, 10, 15, 20])
                        ChoiceChip(
                          label: Text('$d%'),
                          selected: discount == d,
                          onSelected: (_) => setState(() => discount = d),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: C.line)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _line('Subtotal', rupee(subtotal)),
                  if (discount > 0) _line('Discount ($discount%)', '-${rupee(discountAmount)}'),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                      Text(rupee(total),
                          style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: BigButton(
                          label: 'Cash',
                          onPressed: saving ? null : () => _save('cash'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: BigButton(
                          label: 'UPI',
                          style: BigStyle.outline,
                          onPressed: saving ? null : () => _save('upi'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: BigButton(
                          label: 'Pay later',
                          style: BigStyle.amber,
                          onPressed: saving ? null : () => _save('due'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _line(String a, String b) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(a, style: const TextStyle(fontSize: 15, color: C.muted)),
            Text(b, style: const TextStyle(fontSize: 15, color: C.muted)),
          ],
        ),
      );
}
