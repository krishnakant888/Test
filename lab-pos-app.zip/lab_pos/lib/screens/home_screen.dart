import 'package:flutter/material.dart';

import '../globals.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';
import 'patient_screen.dart';
import 'results_screen.dart';
import 'settings_screen.dart';
import 'storage_screen.dart';
import 'visits_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Listenable.merge([store, cloud]),
          builder: (context, _) {
            final visits = store.visits;

            var collection = visits
                .where((v) => v.payMode != 'due' && isToday(v.createdAt))
                .fold<int>(0, (s, v) => s + v.total);
            collection += visits
                .where((v) => v.payMode == 'due' && v.duePaidAt != null && isToday(v.duePaidAt!))
                .fold<int>(0, (s, v) => s + v.total);
            final todayCount = visits.where((v) => isToday(v.createdAt)).length;

            final dues = visits.where((v) => v.isDue).toList();
            final dueAmount = dues.fold<int>(0, (s, v) => s + v.total);
            final pending = visits.where((v) => !v.resultsComplete).length;
            final recent = visits.take(5).toList();
            final labName = store.lab.name.isEmpty ? 'Set up your lab' : store.lab.name;

            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(labName,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                          Text(todayLabel(),
                              style: const TextStyle(fontSize: 15, color: C.muted)),
                        ],
                      ),
                    ),
                    IconButton.outlined(
                      tooltip: 'Settings',
                      onPressed: () => go(context, const SettingsScreen()),
                      icon: const Icon(Icons.tune),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _backupBanner(context),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                            color: C.primary, borderRadius: BorderRadius.circular(20)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Collection today',
                                style: TextStyle(fontSize: 14, color: C.tint)),
                            const SizedBox(height: 4),
                            Text(rupee(collection),
                                style: const TextStyle(
                                    fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white)),
                            Text('$todayCount patients',
                                style: const TextStyle(fontSize: 14, color: C.tint)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: C.line),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Due to collect',
                                style: TextStyle(fontSize: 14, color: C.muted)),
                            const SizedBox(height: 4),
                            Text(rupee(dueAmount),
                                style: const TextStyle(
                                    fontSize: 28, fontWeight: FontWeight.w800, color: C.amberText)),
                            Text('${dues.length} patients',
                                style: const TextStyle(fontSize: 14, color: C.muted)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (pending > 0)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Material(
                      color: C.amberBg,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                        side: const BorderSide(color: C.amberLine),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(18),
                        onTap: () => go(context, const VisitsScreen(pendingOnly: true)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                          child: Row(
                            children: [
                              const Icon(Icons.description_outlined, color: C.amberText),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  '$pending report${pending == 1 ? '' : 's'} waiting for results',
                                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                                ),
                              ),
                              const Icon(Icons.chevron_right, color: C.amberText),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                BigButton(
                  label: 'New patient bill',
                  icon: Icons.add,
                  height: 60,
                  onPressed: () => go(context, const PatientScreen()),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: BigButton(
                        label: 'Enter results',
                        style: BigStyle.outline,
                        height: 52,
                        onPressed: () => go(context, const VisitsScreen(pendingOnly: true)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: BigButton(
                        label: 'All patients',
                        style: BigStyle.outline,
                        height: 52,
                        onPressed: () => go(context, const VisitsScreen()),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                const Text('Recent patients',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                if (recent.isEmpty)
                  const Box(
                    child: Text('No patients yet. Tap "New patient bill" to start.',
                        style: TextStyle(color: C.muted, fontSize: 15)),
                  ),
                for (final v in recent)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: VisitTile(
                      visit: v,
                      onTap: () => go(context, ResultsScreen(visitId: v.id)),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _backupBanner(BuildContext context) {
    if (cloud.driveFull) {
      return _banner(
        context,
        'Google Drive is almost full. Tap to switch account.',
        C.amberBg,
        C.amberLine,
        C.amberText,
      );
    }
    if (!cloud.connected) {
      return _banner(
        context,
        'Backup is off. Tap to connect Google Drive.',
        C.tint,
        C.line,
        C.primary,
      );
    }
    return const SizedBox.shrink();
  }

  Widget _banner(BuildContext context, String text, Color bg, Color line, Color fg) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: bg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: line),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => go(context, const StorageScreen()),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Icon(Icons.cloud_outlined, color: fg),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(text,
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: fg)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
