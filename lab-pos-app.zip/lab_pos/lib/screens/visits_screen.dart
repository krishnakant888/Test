import 'package:flutter/material.dart';

import '../globals.dart';
import '../theme.dart';
import '../widgets.dart';
import 'results_screen.dart';

class VisitsScreen extends StatefulWidget {
  const VisitsScreen({super.key, this.pendingOnly = false});

  final bool pendingOnly;

  @override
  State<VisitsScreen> createState() => _VisitsScreenState();
}

class _VisitsScreenState extends State<VisitsScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.pendingOnly ? 'Enter results' : 'All patients')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: store,
          builder: (context, _) {
            final q = query.trim().toLowerCase();
            final list = store.visits.where((v) {
              if (widget.pendingOnly && v.signedAt != null) return false;
              if (q.isEmpty) return true;
              return v.patient.name.toLowerCase().contains(q) ||
                  v.billNo.toLowerCase().contains(q) ||
                  v.patient.mobile.contains(q);
            }).toList();

            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
              children: [
                TextField(
                  decoration: field('Search name, mobile or bill no.')
                      .copyWith(prefixIcon: const Icon(Icons.search)),
                  onChanged: (t) => setState(() => query = t),
                ),
                const SizedBox(height: 14),
                if (list.isEmpty)
                  const Box(
                    child: Text('Nothing here yet.', style: TextStyle(color: C.muted)),
                  ),
                for (final v in list)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: VisitTile(
                      visit: v,
                      onTap: () => go(context, ResultsScreen(visitId: v.id)),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
