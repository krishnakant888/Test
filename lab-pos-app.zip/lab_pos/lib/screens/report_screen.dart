import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../globals.dart';
import '../models.dart';
import '../pdf_report.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key, required this.visitId});

  final String visitId;

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  bool working = false;

  Visit? get visit {
    for (final v in store.visits) {
      if (v.id == widget.visitId) return v;
    }
    return null;
  }

  Future<void> _sign(Visit v) async {
    if (working) return;
    if (!v.resultsComplete) {
      toast(context, 'Some results are still empty. Go back and fill them in.');
      return;
    }
    setState(() => working = true);
    try {
      final file = await buildReportPdf(v, store.lab, store.reportsDir);
      final result = await Share.shareXFiles(
        [XFile(file.path, mimeType: 'application/pdf')],
        text: 'Lab report for ${v.patient.name} (${v.billNo})',
      );
      if (result.status != ShareResultStatus.dismissed) {
        v.signedAt = DateTime.now().millisecondsSinceEpoch;
        await store.saveVisit(v);
        // A copy of the PDF goes to Drive too. If this fails nothing is lost.
        await cloud.uploadReport('${v.billNo}.pdf', await file.readAsBytes());
      }
    } catch (e) {
      if (mounted) toast(context, 'Could not make the report: $e');
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  Future<void> _markPaid(Visit v) async {
    v.duePaidAt = DateTime.now().millisecondsSinceEpoch;
    await store.saveVisit(v);
    if (mounted) toast(context, 'Payment recorded');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final v = visit;
        if (v == null) {
          return Scaffold(
            appBar: AppBar(),
            body: const Center(child: Text('This patient was not found')),
          );
        }
        final lab = store.lab;
        final g = v.patient.gender;

        return Scaffold(
          appBar: AppBar(title: const Text('Report')),
          body: SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
                    children: [
                      Box(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(lab.name.isEmpty ? '[Lab name - set in Settings]' : lab.name,
                                style: const TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.w800, color: C.primary)),
                            if (lab.address.isNotEmpty || lab.phone.isNotEmpty)
                              Text([lab.address, lab.phone].where((s) => s.isNotEmpty).join('  |  '),
                                  style: const TextStyle(fontSize: 13, color: C.muted)),
                            const Divider(height: 24),
                            Text(v.patient.name,
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                            Text(
                                '${v.patient.ageSex}  •  Sample ${v.billNo}  •  ${fmtDate(v.createdAt)}',
                                style: const TextStyle(fontSize: 14, color: C.muted)),
                            Text('Referred by ${v.patient.referredBy}',
                                style: const TextStyle(fontSize: 14, color: C.muted)),
                            const SizedBox(height: 14),
                            for (final t in v.tests) ...[
                              Text(t.name,
                                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                              const SizedBox(height: 4),
                              for (final p in t.params) _row(p, t.values[p.name] ?? '', g),
                              const SizedBox(height: 10),
                            ],
                            const Divider(height: 24),
                            Text(lab.pathologist.isEmpty ? '[Pathologist name]' : lab.pathologist,
                                style: const TextStyle(fontWeight: FontWeight.w800)),
                            Text(
                              '${lab.qualification.isEmpty ? '[Qualification]' : lab.qualification}  |  Reg. no. ${lab.regNo.isEmpty ? '[Registration no.]' : lab.regNo}',
                              style: const TextStyle(fontSize: 13, color: C.muted),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      if (v.isDue)
                        Box(
                          color: C.amberBg,
                          border: C.amberLine,
                          child: Row(
                            children: [
                              Expanded(
                                child: Text('${rupee(v.total)} is still to be collected',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700, color: C.amberText)),
                              ),
                              TextButton(
                                onPressed: () => _markPaid(v),
                                child: Text('Mark ${rupee(v.total)} as paid'),
                              ),
                            ],
                          ),
                        ),
                      if (v.signedAt != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text('Report shared on ${fmtDate(v.signedAt!)}, ${fmtTime(v.signedAt!)}',
                              style: const TextStyle(color: C.muted)),
                        ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(top: BorderSide(color: C.line)),
                  ),
                  child: BigButton(
                    label: working
                        ? 'Please wait...'
                        : (v.signedAt == null ? 'Sign and share PDF' : 'Share PDF again'),
                    icon: Icons.ios_share,
                    height: 60,
                    onPressed: working ? null : () => _sign(v),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _row(Param p, String value, String gender) {
    final f = p.flag(value, gender);
    final color = f == 'HIGH' ? C.redText : (f == 'LOW' ? C.blueText : C.ink);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(flex: 4, child: Text(p.name, style: const TextStyle(fontSize: 14))),
          Expanded(
            flex: 3,
            child: Text(
              value.isEmpty ? '-' : '$value ${p.unit}',
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: f == 'LOW' || f == 'HIGH' ? FontWeight.w800 : FontWeight.w600,
                  color: color),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(p.rangeText(gender),
                textAlign: TextAlign.right,
                style: const TextStyle(fontSize: 13, color: C.muted)),
          ),
        ],
      ),
    );
  }
}
