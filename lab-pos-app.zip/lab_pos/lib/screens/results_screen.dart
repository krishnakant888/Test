import 'dart:convert';

import 'package:flutter/material.dart';

import '../globals.dart';
import '../models.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';
import 'report_screen.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key, required this.visitId});

  final String visitId;

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  Visit? visit;
  final Map<String, TextEditingController> ctrl = {};

  @override
  void initState() {
    super.initState();
    final found = store.visits.where((v) => v.id == widget.visitId).toList();
    if (found.isNotEmpty) {
      // Work on a copy, so nothing changes until Save is tapped.
      visit = Visit.fromJson(
          jsonDecode(jsonEncode(found.first.toJson())) as Map<String, dynamic>);
      final v = visit!;
      for (var i = 0; i < v.tests.length; i++) {
        for (final p in v.tests[i].params) {
          ctrl['$i|${p.name}'] = TextEditingController(text: v.tests[i].values[p.name] ?? '');
        }
      }
    }
  }

  @override
  void dispose() {
    for (final c in ctrl.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _collect() {
    final v = visit!;
    for (var i = 0; i < v.tests.length; i++) {
      final t = v.tests[i];
      for (final p in t.params) {
        final text = ctrl['$i|${p.name}']!.text.trim();
        if (text.isEmpty) {
          t.values.remove(p.name);
        } else {
          t.values[p.name] = text;
        }
      }
    }
  }

  Future<void> _saveDraft() async {
    _collect();
    await store.saveVisit(visit!);
    if (mounted) toast(context, 'Results saved');
  }

  Future<void> _preview() async {
    _collect();
    await store.saveVisit(visit!);
    if (!mounted) return;
    go(context, ReportScreen(visitId: visit!.id));
  }

  @override
  Widget build(BuildContext context) {
    final v = visit;
    if (v == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('This patient was not found')),
      );
    }
    final g = v.patient.gender;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(v.patient.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            Text('${v.patient.ageSex}  •  ${v.billNo}  •  ${fmtDate(v.createdAt)}',
                style: const TextStyle(fontSize: 14, color: C.muted, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                children: [
                  for (var i = 0; i < v.tests.length; i++) ...[
                    Text(v.tests[i].name,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    if (v.tests[i].params.isEmpty)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 12),
                        child: Text(
                          'This test has no result fields. Add them in Settings > Tests and prices.',
                          style: TextStyle(color: C.muted),
                        ),
                      ),
                    for (final p in v.tests[i].params) _paramRow(i, p, g),
                    const SizedBox(height: 14),
                  ],
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: C.line)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: BigButton(
                      label: 'Save draft',
                      style: BigStyle.outline,
                      onPressed: _saveDraft,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: BigButton(label: 'Preview report', onPressed: _preview),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _paramRow(int i, Param p, String gender) {
    final c = ctrl['$i|${p.name}']!;
    final range = p.rangeText(gender);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Box(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Expanded(
              flex: 5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  Text(
                    [if (range.isNotEmpty) 'Normal $range', if (p.unit.isNotEmpty) p.unit].join('  '),
                    style: const TextStyle(fontSize: 13, color: C.muted),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 3,
              child: TextField(
                controller: c,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: field('Result'),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(width: 64, child: flagPill(p.flag(c.text, gender))),
          ],
        ),
      ),
    );
  }
}
