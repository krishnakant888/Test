import 'dart:async';

import 'package:extension_google_sign_in_as_googleapis_auth/extension_google_sign_in_as_googleapis_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as gd;

import 'store.dart';

const String _rootFolderName = 'LabPOS Data';

class Quota {
  Quota(this.used, this.limit);
  final int used;
  final int? limit; // null means no limit (some Workspace accounts)

  double? get fraction {
    final l = limit;
    if (l == null || l == 0) return null;
    return used / l;
  }
}

/// Backs the lab's files up to the lab's own Google Drive and brings in
/// files from other phones. Uses only the "drive.file" permission, so the app
/// can see only the files it created itself.
class DriveSync extends ChangeNotifier {
  DriveSync(this.store);

  final LabStore store;
  final GoogleSignIn _gsi = GoogleSignIn(scopes: <String>[gd.DriveApi.driveFileScope]);
  final Map<String, String> _folderCache = {};
  Timer? _debounce;

  GoogleSignInAccount? account;
  bool busy = false;
  bool driveFull = false;
  bool lastFailed = false;
  String status = '';
  Quota? quota;

  bool get connected => account != null;
  String get email => account?.email ?? store.device.driveEmail ?? '';

  void _set(String message, {bool failed = false}) {
    status = message;
    lastFailed = failed;
    notifyListeners();
  }

  /// Called when the app starts. Signs in again silently if possible.
  Future<void> init() async {
    try {
      account = await _gsi.signInSilently();
    } catch (_) {
      account = null;
    }
    notifyListeners();
    if (account != null) unawaited(syncNow());
  }

  /// First-time sign in, or sign in again.
  Future<void> connect() async {
    try {
      final acc = await _gsi.signIn();
      if (acc == null) {
        _set('Sign-in cancelled', failed: true);
        return;
      }
      account = acc;
      _folderCache.clear();
      await store.setDriveEmail(acc.email);
      notifyListeners();
      await syncNow();
    } catch (e) {
      _set(_friendly(e), failed: true);
    }
  }

  /// Starts a backup a few seconds after the last change.
  void scheduleSync() {
    if (!connected) return;
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 4), () {
      unawaited(syncNow());
    });
  }

  Future<gd.DriveApi> _api() async {
    final client = await _gsi.authenticatedClient();
    if (client == null) throw StateError('Not signed in to Google Drive');
    return gd.DriveApi(client);
  }

  Future<String> _folder(gd.DriveApi api, String name, {String? parent}) async {
    final key = '${parent ?? 'root'}/$name';
    final cached = _folderCache[key];
    if (cached != null) return cached;
    final q = StringBuffer(
        "mimeType='application/vnd.google-apps.folder' and name='$name' and trashed=false");
    if (parent != null) q.write(" and '$parent' in parents");
    final res = await api.files.list(q: q.toString(), spaces: 'drive', $fields: 'files(id,name)');
    final files = res.files ?? <gd.File>[];
    String id;
    if (files.isNotEmpty) {
      id = files.first.id!;
    } else {
      final created = await api.files.create(
        gd.File(
          name: name,
          mimeType: 'application/vnd.google-apps.folder',
          parents: parent == null ? null : <String>[parent],
        ),
        $fields: 'id',
      );
      id = created.id!;
    }
    _folderCache[key] = id;
    return id;
  }

  Future<Map<String, gd.File>> _remoteFiles(gd.DriveApi api, String folder) async {
    final out = <String, gd.File>{};
    String? token;
    do {
      final res = await api.files.list(
        q: "'$folder' in parents and trashed=false and mimeType!='application/vnd.google-apps.folder'",
        spaces: 'drive',
        pageSize: 1000,
        pageToken: token,
        $fields: 'nextPageToken,files(id,name,appProperties)',
      );
      for (final f in res.files ?? <gd.File>[]) {
        if (f.name != null) out[f.name!] = f;
      }
      token = res.nextPageToken;
    } while (token != null);
    return out;
  }

  Future<void> _upload(
    gd.DriveApi api,
    String folder,
    String name,
    String? existingId,
    int updatedAt,
    List<int> bytes, {
    String mime = 'application/json',
  }) async {
    final media = gd.Media(Stream<List<int>>.value(bytes), bytes.length, contentType: mime);
    final meta = gd.File(appProperties: <String, String>{'u': '$updatedAt'});
    if (existingId == null) {
      meta.name = name;
      meta.parents = <String>[folder];
      await api.files.create(meta, uploadMedia: media, $fields: 'id');
    } else {
      await api.files.update(meta, existingId, uploadMedia: media, $fields: 'id');
    }
  }

  Future<List<int>> _download(gd.DriveApi api, String id) async {
    final res = await api.files.get(id, downloadOptions: gd.DownloadOptions.fullMedia) as gd.Media;
    final out = <int>[];
    await for (final chunk in res.stream) {
      out.addAll(chunk);
    }
    return out;
  }

  Future<void> _refreshQuota(gd.DriveApi api) async {
    final about = await api.about.get($fields: 'storageQuota');
    final q = about.storageQuota;
    if (q == null) return;
    quota = Quota(int.tryParse(q.usage ?? '') ?? 0, int.tryParse(q.limit ?? ''));
    final f = quota!.fraction;
    driveFull = f != null && f >= 0.9;
  }

  /// Two-way copy. For every file, the newer version wins.
  Future<void> _syncInner() async {
    final api = await _api();
    final folder = await _folder(api, _rootFolderName);
    final remote = await _remoteFiles(api, folder);
    final local = await store.syncFileNames();
    final localSet = local.toSet();
    var up = 0;
    var down = 0;

    for (final name in local) {
      final lu = await store.updatedAtOf(name);
      final r = remote[name];
      final ru = int.tryParse(r?.appProperties?['u'] ?? '');
      if (r == null) {
        await _upload(api, folder, name, null, lu, await store.readBytes(name));
        up++;
      } else if (ru == null || lu > ru) {
        await _upload(api, folder, name, r.id, lu, await store.readBytes(name));
        up++;
      } else if (ru > lu) {
        final ok = await store.writeFromDrive(name, await _download(api, r.id!));
        if (ok) down++;
      }
    }
    for (final e in remote.entries) {
      if (localSet.contains(e.key) || !syncNameRe.hasMatch(e.key)) continue;
      final ok = await store.writeFromDrive(e.key, await _download(api, e.value.id!));
      if (ok) down++;
    }

    if (down > 0) await store.reload();
    await store.markSynced();
    try {
      await _refreshQuota(api);
    } catch (_) {}
    _set(up == 0 && down == 0
        ? 'Everything is backed up'
        : 'Backed up: $up sent, $down received');
  }

  Future<void> syncNow() async {
    if (busy || !connected) return;
    busy = true;
    _set('Backing up...');
    try {
      await _syncInner();
    } catch (e) {
      final msg = e.toString().toLowerCase();
      if (msg.contains('quota') && (msg.contains('exceed') || msg.contains('storage'))) {
        driveFull = true;
      }
      _set(_friendly(e), failed: true);
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  /// Moves backups to another Google account. Steps:
  /// 1. Try one last backup to the old account.
  /// 2. Sign in with the new account.
  /// 3. Copy everything and check that every file arrived.
  /// The old account is never changed or deleted.
  /// Returns a message for the user. Throws if the copy could not be completed.
  Future<String> switchAccount() async {
    if (busy) return 'Please wait, a backup is running';
    busy = true;
    _set('Switching account...');
    try {
      if (connected) {
        try {
          await _syncInner();
        } catch (_) {
          // The old Drive may be full. That is fine, the phone still has every file.
        }
      }
      await _gsi.signOut();
      account = null;
      _folderCache.clear();
      driveFull = false;
      quota = null;
      notifyListeners();

      final acc = await _gsi.signIn();
      if (acc == null) {
        _set('Switch cancelled. Tap Connect to sign in again.', failed: true);
        return 'Switch cancelled. Your data is safe on this phone.';
      }
      account = acc;
      await store.setDriveEmail(acc.email);

      final api = await _api();
      await _refreshQuota(api);
      final need = await store.totalSyncBytes();
      final q = quota;
      if (q != null && q.limit != null && (q.limit! - q.used) < need + 5 * 1024 * 1024) {
        throw StateError('The new account does not have enough free space');
      }

      await _syncInner();

      // Check that every file is on the new account.
      final folder = await _folder(api, _rootFolderName);
      final remote = await _remoteFiles(api, folder);
      for (final name in await store.syncFileNames()) {
        final lu = await store.updatedAtOf(name);
        final ru = int.tryParse(remote[name]?.appProperties?['u'] ?? '');
        if (ru == null || ru < lu) throw StateError('Some files did not reach the new account');
      }
      _set('Now backing up to ${acc.email}');
      return 'Switched to ${acc.email}. All files were copied and checked.';
    } catch (e) {
      final text = _friendly(e);
      _set(text, failed: true);
      throw StateError(text);
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  /// Puts a finished PDF report in the Reports folder on Drive. Failure is ignored.
  Future<void> uploadReport(String fileName, List<int> bytes) async {
    if (!connected) return;
    try {
      final api = await _api();
      final root = await _folder(api, _rootFolderName);
      final reports = await _folder(api, 'Reports', parent: root);
      final existing = await api.files.list(
        q: "name='$fileName' and '$reports' in parents and trashed=false",
        $fields: 'files(id)',
      );
      final list = existing.files ?? <gd.File>[];
      await _upload(
        api,
        reports,
        fileName,
        list.isEmpty ? null : list.first.id,
        DateTime.now().millisecondsSinceEpoch,
        bytes,
        mime: 'application/pdf',
      );
    } catch (_) {}
  }

  String _friendly(Object e) {
    final s = e.toString();
    final lower = s.toLowerCase();
    if (s.contains('ApiException: 10') || lower.contains('sign_in_failed')) {
      return 'Google sign-in is not set up for this app yet. Follow "Google Drive setup" in the README.';
    }
    if (lower.contains('network') || lower.contains('socketexception') || lower.contains('failed host lookup')) {
      return 'No internet. The data is safe on this phone and will back up later.';
    }
    if (lower.contains('quota') && (lower.contains('exceed') || lower.contains('storage'))) {
      return 'Google Drive is full. Switch to another account.';
    }
    if (e is StateError) return e.message;
    return 'Backup problem: $s';
  }
}
