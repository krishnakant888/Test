import 'drive_sync.dart';
import 'store.dart';

/// The two app-wide services, created once in main().
late LabStore store;
late DriveSync cloud;
