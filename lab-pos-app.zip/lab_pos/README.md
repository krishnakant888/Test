# Lab POS - pathology lab billing and reports (Android)

Registers patients, makes bills, takes test results with Low/High flags, and shares a PDF report.
No database and no server. Data is saved as plain files on the phone and copied to **your own Google Drive**.

**Important - read first**
- This code was written but **not compiled or tested** (the workspace it was written in has no Flutter). The first build may show a few errors. Copy the red error text from the GitHub build log and send it back to get a fix.
- The normal ranges in the price list are **samples only**. Your pathologist must check every range before real patients get reports.
- Reports are medical documents. The pathologist should review the first few PDFs.

---

## Part 1 - Get the APK (about 15 minutes)

1. Make a free account at github.com.
2. Click **+** > **New repository**. Name it `lab-pos`. Choose **Private**. Click **Create repository**.
3. Click **uploading an existing file**. Unzip `lab-pos-app.zip` on your computer, then drag in everything inside the folder (the `lib` folder, `.github` folder, `pubspec.yaml`, and the other files). Click **Commit changes**.
   - The `.github` folder is hidden on some computers. If you cannot see it, turn on "show hidden files". Without it, nothing will build.
4. Add the signing secrets (needed for Google Drive sign-in):
   - Open `signing-secrets.txt` (sent separately).
   - In your repository: **Settings** > **Secrets and variables** > **Actions** > **New repository secret**.
   - Make 3 secrets with these exact names: `KEY_ALIAS`, `KEYSTORE_PASSWORD`, `KEYSTORE_BASE64`. Paste the value from the file for each.
5. Click the **Actions** tab > **Build APK** > **Run workflow**. Wait about 6 to 10 minutes.
6. Open the finished run. At the bottom, under **Artifacts**, download `lab-pos-apk`. Unzip it to get `lab-pos.apk`.
7. Send `lab-pos.apk` to the phone (WhatsApp to yourself, Drive, USB). Open it. Allow "install unknown apps" when asked.

If the run shows a red cross, open it, click the failed step, copy the error lines and send them to me.

## Part 2 - Turn on Google Drive backup (one time, about 15 minutes)

The app can already be used without this. Without it, data stays on one phone only.

1. Go to console.cloud.google.com and sign in with the Google account you will use for the lab.
2. Create a project (name: `Lab POS`).
3. **APIs and Services** > **Library** > search **Google Drive API** > **Enable**.
4. **APIs and Services** > **OAuth consent screen**. Choose **External**. Fill the app name (`Lab POS`) and your email. Under **Test users**, add the Gmail address of every account that will be used for backup, including any spare account you may switch to later.
5. **APIs and Services** > **Credentials** > **Create credentials** > **OAuth client ID** > type **Android**.
   - Package name: `in.labpos.lab_pos`
   - SHA-1: copy it from `signing-secrets.txt`
6. Create. You do not need to download anything.
7. On the phone: open the app > Settings (top right) > **Storage and backup** > **Connect Google Drive** and pick the account.

Notes
- While the consent screen is in **Testing**, Google may ask you to sign in again about every 7 days. The app keeps working, and data stays on the phone. Sign in again from Storage and backup.
- Only the folder **LabPOS Data** (created by the app) is visible to the app. It cannot read your other Drive files.

## Using it with more than one phone

1. Install the same APK on each phone and connect the **same** Google account.
2. In **Lab details**, give each phone a different **bill prefix** (A, B, ...). Bill numbers then never repeat.
3. Each phone writes its own patient files. Two phones editing the same patient at the same time: the later save wins.

## Changing Google account (when Drive is full)

Settings > Storage and backup > **Switch Drive account**. The app makes a last backup, signs in to the new account, copies every file, and checks each one arrived. If anything fails, your data stays on the phone and the old account is untouched. Add the new account as a Test user first (Part 2, step 4).

## Differences from the mock-up
- No QR scan and no bottom menu bar (everything starts from the home screen).
- "Home collection" is only a tick box.
- Deleting patients is not available. Nothing is deleted from Drive.
- The price list is shared across phones as one file, so edit it on one phone at a time.
- PDF uses a basic font. The rupee sign prints as "Rs." in the PDF.

## Before real use
- Check all normal ranges with the pathologist.
- Add the pathologist name, qualification and registration number in Lab details.
- The key in `signing-secrets.txt` is a test key. Make your own before publishing on Google Play.
